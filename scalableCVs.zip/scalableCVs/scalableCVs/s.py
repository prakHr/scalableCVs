import scalableCVs 
from scalableCVs import cv
from pprint import pprint


if __name__ == "__main__":

    
    filters_list = [
        {
            "image_file_path":r"C:\Users\gprak\Downloads\Github Repos\Portfolio-Site\brandImages\logo1.png",
            "brightness":1.2,
            "contrast":0.9,
            "saturation":None
        },
        {
            "image_file_path":r"C:\Users\gprak\Downloads\Github Repos\Portfolio-Site\brandImages\logo1.png",
            "brightness":1.2,
            "contrast":0.8,
            "saturation":1.2
        }
    ]
    show_progress = True
    results = cv.apply_filters(filters_list,show_progress)
    pprint(results)
    