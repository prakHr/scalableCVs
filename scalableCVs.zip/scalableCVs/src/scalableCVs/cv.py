import os
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import pygame
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import multiprocessing
from pathlib import Path
from mpire import WorkerPool
from litecv import open_image

def apply_filter(image_file_path,brightness,contrast,saturation):
    img = open_image(image_file_path)
    if brightness:
        img.brightness(brightness)
    if contrast:
        img.contrast(contrast)    
    if saturation:
        img.saturation(saturation)  
    return img

def apply_filters(filters_list,show_progress):
    results = []
    for i,filters in enumerate(filters_list):
        my_dict = {}
        my_dict["image_file_path"] = filters["image_file_path"]
        my_dict["brightness"] = filters["brightness"]
        my_dict["contrast"] = filters["contrast"]
        my_dict["saturation"] = filters["saturation"]
        results.append(my_dict)
    num_cores = max(multiprocessing.cpu_count()//2,1)
    with WorkerPool(n_jobs=num_cores,daemon=False) as pool:
        results = pool.map(apply_filter,results,progress_bar=show_progress)
    return results

def save_img(img,image_file_path):
    img.save(image_file_path)

if __name__=="__main__":
    
    filters_list = [
        {
            "image_file_path":r"C:\Users\gprak\Downloads\Github Repos\Portfolio-Site\brandImages\logo1.png",
            "brightness":1.2,
            "contrast":0.9,
            "saturation":None
        },
        {
            "image_file_path":r"C:\Users\gprak\Downloads\Github Repos\Portfolio-Site\brandImages\logo1.png",
            "brightness":1.2,
            "contrast":0.8,
            "saturation":1.2
        }
    ]
    show_progress = True
    results = apply_filters(filters_list,show_progress)
    